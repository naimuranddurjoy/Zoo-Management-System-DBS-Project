<footer>
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-sm-6">
							<div class="widget">
								<h5 class="widgetheading">Our Contact</h5>
								<address>
									<strong>BRACU ZOO </strong><br>
									Merul Badda<br>
								Dhaka</address>
								<p>
									<i class="icon-phone"></i> 01841983923 <br>
									<i class="icon-envelope-alt"></i> chowdhury.shadab.aiman@g.braacu.ac.bd
								</p>
							</div>
						</div>
						<div class="col-md-push-4 col-sm-6">
							<div class="widget">
								<h5 class="widgetheading">Quick Links</h5>
								<ul class="link-list">
									<li><a href="index.php">Home</a></li>
									<li><a href="portfolio.php">Gallery</a></li>
									<li><a href="animals.php">Animals</a></li>
									<li><a href="about.php">About</a></li>
									<li><a href="contact.php">Contact us</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div id="sub-footer">
					<div class="container">
						<div class="row">
							<div class="col-lg-6">
								<div class="copyright">
									<p>
										<span>&copy; <script> document.write(new Date().getFullYear()); </script> All right reserved.  </span><a href="http://Brac_university_Zoo.com" target="_blank">Zoo Management System</a>
									</p>
								</div>
							</div>
							<div class="col-lg-6">
								<ul class="social-network">
									<li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
									<li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
									<li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</footer>